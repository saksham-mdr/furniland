import React from 'react'
import './csscat/categorys.css';



import bedroom from '../image/bedroom.svg';
import livingroom from '../image/livingroom.svg';
import dining from '../image/dining.svg';
import kitchen from '../image/kitchen.svg';
import office from '../image/office.svg';
import { BrowserRouter as Router,Routes,Outlet, Link } from "react-router-dom";
export default function Livingroom() {
  return (
    <div>
        <div id="moreCats">
 
        <div className="categorys">
        <Link  to='/bedroom' className='a'>
      
        <div className="svgImg">
                    <img src={bedroom} class="small" alt="Bedroom" />
                    {/* style="width:50px" */}
                </div>
                <p class="ttl">Bedroom</p>
        </Link>
        </div>  

        <div className="categorys">
        <Link  to='/office' className='a'>
        <div className="svgImg"> 
                    <img src={office}  class="small" alt="Office" />
                </div>
                <p class="ttl">Office</p>
            </Link>
        </div>

        <div className="categorys">
    
        <Link  to='/kitchen' className='a'>
                <div className="svgImg">
                    <img src={kitchen}  class="small"  alt="Kitchen" /> 
                </div>
                <p class="ttl">Kitchen</p>
                </Link>
        </div>

        <div className="categorys">
       
        <Link  to='/dining' className='a'>
        <div className="svgImg">
                    <img src={dining }   class="small" alt="Dining" />
                </div>
                <p class="ttl">Dining</p>
            </Link>
        </div>

        <div className="categorys  active">
        <Link  to='/livingroom' className='a'>
        
                <div className="svgImg">
                    <img src={livingroom}  class="small" alt="Livingroom" />   
                    {/* style="width:50px" */}
                </div>
                <p class="ttl">Livingroom</p>
           </Link>
        </div>  
        
    </div>
    <div className="wrapall">
      
        
        

                  <div id="sorting" >
                
                      <form method="post">
                          <select name="sort">
                              <option value="" selected hidden>Sort By</option>
                              <option value="maxprice">Maximum Price</option>
                              <option value="minprice">Minimum Price</option>
                          </select>

                          <input type="submit" name="orderSearch" value="Sort"/>
                      </form>

                  </div> 

                  <div id="titles">
                      <h5> Livingroom Category </h5>
                  </div>
        
        <div id="arrange">
            
                <div className="boxe">
                    <a href="tproductcrud"></a>
                    <img src="../image"/> 
                   
                    {/* style="height:50px" */}
                    <p>£ "PRICE"</p>
                    <div className="buy-btn">
                        <a href="productview" >Buy Now</a>
                    </div>
                </div>
         
        </div>
        </div>
        <Outlet/>
    </div>
  )
}
