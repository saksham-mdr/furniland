import React from 'react'
import './css/Error.css'
export default function Error() {
  return (
    <div><h1 className='error'> Incorect address</h1> </div>
  )
}
