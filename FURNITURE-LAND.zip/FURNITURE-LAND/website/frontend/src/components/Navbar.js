import React from 'react'
// import './css/nav.css';
import {Outlet } from 'react-router-dom';
// import Logo from './image/Ebasket_logo.png';
import Logo from './image/furnitureland.png';
export default function Navbar() {
  return (
    <div>


<section id="nav">
        <nav className="navbar navbar-expand-lg navbar-light shadow-lg p-3 mb-5 bg-white rounded">
            <a className="navbar-brand" href="/"><img src={Logo} alt="furmitureland.logo" width="100%"/></a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
          
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
               <form className="form-inline my-2 my-lg-0 bg-white" action="Customer/#" method="post">
                    <input className="form-control mr-sm-2" name="search" type="search" placeholder="Search by Name, Category or Shop..." aria-label="Search"/>
       
                </form> 
    
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item active user control">
                            <a className="nav-link" href="index.html"><i className="fa fa-user"></i>  <i className="fas fa-caret-down"></i>  </a>
                            <a className="managedets" href="#">Manage Customer Details</a>
                        </li>
                        
                        <li className="nav-item active logout control">
                            <a className="nav-link" href="Session/#"><i className="fas fa-sign-out-alt"></i>Logout</a>
                        </li>
                    </ul>
              
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item active control">
                        <a className="nav-link" href="Session/#"><i className="fa fa-user"></i>SignIn</a>
                        </li>
                        <li className="nav-item  control">
                          
                            <a className="nav-link" href="#"><i className="fa fa-box-open"></i>Trader</a>
                        </li>
                        <li className="nav-item active">
                            <a className="nav-link" href="#"><i className="fa fa-shopping-cart"></i> Items </a>
                        </li>
                    </ul>
           
            </div> 
          </nav>
          </section>
          <Outlet/>   

    

   
  </div>

  )
}
