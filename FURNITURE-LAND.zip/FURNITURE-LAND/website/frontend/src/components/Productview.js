import React from 'react';


import'./css/productView.css';



const Productview = props => {

	

    return (
        <div>
    <div id="content-wrapper">
		

		<div className="column">
			<img id='featured' src="images/shoe1.jpg"/>

			<div id="slide-wrapper" >
				<img id="slideLeft" className="arrow" src="images/arrow-left.png"/>

				<div id="slider">
					<img className="thumbnail active" src="images/shoe1.jpg"/>
					<img className="thumbnail" src="images/shoe2.jpg"/>
					<img className="thumbnail" src="images/shoe3.jpg"/>

					<img className="thumbnail" src="images/preset1.png"/>
					<img className="thumbnail" src="images/preset2.jpg"/>
					<img className="thumbnail" src="images/preset3.jpg"/>
					<img className="thumbnail" src="images/preset4.jpg"/>
				</div>

				<img id="slideRight" className="arrow" src="images/arrow-right.png"/>
			</div>
		</div>

		<div className="column">
			<h1>product id</h1>
			<h5>#product.categories</h5>
			<hr></hr>
			<h5>$Price</h5>
			
			<p>DISCRIPTION Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            <h3>LOCATION</h3>
			<input type="number" id="quantity" name="quantity" min="1" max="5"/>
			<a className="btn btn-dark" href="#">Add to Cart</a>
		</div>

	</div>

        </div>

        
    );
}





export default Productview;
