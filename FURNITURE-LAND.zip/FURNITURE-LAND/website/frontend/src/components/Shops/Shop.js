import React from 'react'
import './shop.css'
import Six from '../image/6.jpg';


export default function Shop() {
  return (
    <div>
    <div>Shop</div>
    <div className="shoptitle">
        <h5>Shops Registered to</h5>
    </div>
    
    <div className="all">
        <div className="shop">
           
             <a href="shopproducts.php"> 
                <div className="shopboxes" onclick="location.href='#';">
                    <img src={Six}/>
                    <div className="block">
                        <p>"SHOP_NAME"</p>
                        <p>"SHOP_LOCATION"</p>
                    </div>
                </div>
                </a>
          
        </div>
    </div>
    </div>
  )
}
